package edu.ucdenver.cse.GRID.MAP;

import java.util.ArrayList;


public class Route {	
	long agentID;
	String agentName;
	
	ArrayList<Road> roads = new ArrayList<Road>();
	
	
	

}
